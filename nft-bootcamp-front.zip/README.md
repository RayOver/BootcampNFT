# WEB3DEV - Mint Sua Própria Coleção de NFT

### **Bem-vind@s 👋**
Para iniciar esse curso, clone esse repositório e digite os seguintes comandos:

1. Execute `npm install` no diretório raiz
2. Execute `npm run start` para iniciar o projeto
3. Agora é só codar!

### **Perguntas?**
Se tiver perguntas, entre [na página do Curso](https://bootcamp.web3dev.com.br/courses/NFT_Collection), faça o link com seu Discord. No [Discord da comunidade](https://discord.web3dev.com.br) você terá acesso aos canais de ajuda e aos monitores de bootcamp.